import { SvgIcon } from "@mui/material";

const FilterList = props => {
  return <SvgIcon viewBox="0 0 24 24" {...props}>
      <path d="M20.5,7H3.5A.5.5,0,0,1,3,6.5v-1A.5.5,0,0,1,3.5,5h17a.5.5,0,0,1,.5.5v1A.5.5,0,0,1,20.5,7ZM18,12.5v-1a.5.5,0,0,0-.5-.5H6.5a.5.5,0,0,0-.5.5v1a.5.5,0,0,0,.5.5h11A.5.5,0,0,0,18,12.5Zm-3,6v-1a.5.5,0,0,0-.5-.5h-5a.5.5,0,0,0-.5.5v1a.5.5,0,0,0,.5.5h5A.5.5,0,0,0,15,18.5Z" />
    </SvgIcon>;
};

export default FilterList;