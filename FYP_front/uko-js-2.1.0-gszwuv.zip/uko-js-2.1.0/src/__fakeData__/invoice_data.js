const INVOICE_LIST = [{
  date: new Date(2021, 11, 2),
  invoiceId: "#872348",
  id: "615193a4c7e1363df77b9929",
  name: "Natalie Dormer",
  avatar: "/static/avatar/001-man.svg",
  status: "Complete",
  email: "Mike1203@gmail.com"
}, {
  invoiceId: "#872349",
  date: new Date(2021, 11, 2),
  id: "615193bab7b256189c6fe997",
  name: "Kyle Williams",
  avatar: "/static/avatar/005-man-1.svg",
  status: "Complete",
  email: "Mike1203@gmail.com"
}, {
  invoiceId: "#872350",
  date: new Date(2021, 11, 2),
  id: "615193d64696d4665abb8ea5",
  name: "Alan Mask",
  avatar: "/static/avatar/014-man-3.svg",
  status: "Complete",
  email: "Mike1203@gmail.com"
}, {
  date: new Date(2021, 11, 2),
  invoiceId: "#872348",
  id: "615193a4c7e1363df77b9929",
  name: "Natalie Dormer",
  avatar: "/static/avatar/001-man.svg",
  status: "Complete",
  email: "Mike1203@gmail.com"
}, {
  invoiceId: "#872349",
  date: new Date(2021, 11, 2),
  id: "615193bab7b256189c6fe997",
  name: "Kyle Williams",
  avatar: "/static/avatar/005-man-1.svg",
  status: "Complete",
  email: "Mike1203@gmail.com"
}];
export default INVOICE_LIST;