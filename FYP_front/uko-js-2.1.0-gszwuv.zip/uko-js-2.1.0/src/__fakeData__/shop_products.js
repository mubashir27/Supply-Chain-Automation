const SHOP_PRODUCTS = [{
  id: 1,
  off: 30,
  new: false,
  price: 120,
  name: "Nike Airmax 270",
  image: "/static/products/shoes/keds-1.png"
}, {
  id: 2,
  off: 0,
  new: true,
  price: 120,
  name: "Nike Airmax 270",
  image: "/static/products/shoes/keds-2.png"
}, {
  id: 3,
  off: 0,
  new: false,
  price: 120,
  name: "Nike Airmax 270",
  image: "/static/products/shoes/keds-3.png"
}, {
  id: 4,
  off: 0,
  new: false,
  price: 120,
  name: "Nike Airmax 270",
  image: "/static/products/shoes/keds-4.png"
}, {
  id: 5,
  off: 0,
  new: false,
  price: 120,
  name: "Nike Airmax 270",
  image: "/static/products/shoes/keds-1.png"
}, {
  id: 6,
  off: 0,
  new: false,
  price: 120,
  name: "Nike Airmax 270",
  image: "/static/products/shoes/keds-5.png"
}, {
  id: 7,
  off: 0,
  new: false,
  price: 120,
  name: "Nike Airmax 270",
  image: "/static/products/shoes/keds-6.png"
}, {
  id: 8,
  off: 0,
  new: false,
  price: 120,
  name: "Nike Airmax 270",
  image: "/static/products/shoes/keds-7.png"
}, {
  id: 9,
  off: 0,
  new: false,
  price: 120,
  name: "Nike Airmax 270",
  image: "/static/products/shoes/keds-4.png"
}];
export default SHOP_PRODUCTS;