export const userListFakeData = [{
  id: "615193a4c7e1363df77b9929",
  name: "Natalie Dormer",
  role: "UI Designer",
  company: "Tesla",
  avatar: "/static/avatar/001-man.svg",
  verified: "Yes",
  address: "Arizona, USA",
  project: "Project X"
}, {
  id: "615193bab7b256189c6fe997",
  name: "Drake",
  role: "Project Manager",
  company: "Ford",
  avatar: "/static/avatar/003-boy.svg",
  verified: "Yes",
  address: "Arizona, USA",
  project: "Project X"
}, {
  id: "615193d64696d4665abb8ea5",
  name: "Gryffin",
  role: "Developer",
  company: "Tesla",
  avatar: "/static/avatar/011-man-2.svg",
  verified: "Yes",
  address: "Arizona, USA",
  project: "Project X"
}];